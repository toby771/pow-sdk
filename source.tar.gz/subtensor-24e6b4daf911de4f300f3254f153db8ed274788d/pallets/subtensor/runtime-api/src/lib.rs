#![cfg_attr(not(feature = "std"), no_std)]
extern crate alloc;
use alloc::collections::BTreeMap;
use alloc::vec::Vec;
use codec::Compact;
use pallet_subtensor::rpc_info::{
    basket_info::{
        BasketClaimPreview, BasketPosition, BasketSummary, BasketTradingStatus, BetaPosition,
        BetaPricing, BetaPricingPage,
    },
    delegate_info::DelegateInfo,
    dynamic_info::DynamicInfo,
    metagraph::{Metagraph, SelectiveMetagraph},
    neuron_info::{NeuronInfo, NeuronInfoLite},
    show_subnet::SubnetState,
    stake_info::{StakeAvailability, StakeInfo},
    subnet_info::{
        SubnetHyperparams, SubnetHyperparamsV2, SubnetHyperparamsV3, SubnetInfo, SubnetInfov2,
    },
};
use pallet_subtensor::staking::lock::LockState;
use sp_runtime::AccountId32;
use substrate_fixed::types::U64F64;
use subtensor_runtime_common::{
    AlphaBalance, MechId, NetUid, ProxyFilterInfo, ProxyTypeInfo, TaoBalance,
};

// Here we declare the runtime API. It is implemented it the `impl` block in
// src/neuron_info.rs, src/subnet_info.rs, and src/delegate_info.rs
sp_api::decl_runtime_apis! {
    pub trait DelegateInfoRuntimeApi {
        fn get_delegates() -> Vec<DelegateInfo<AccountId32>>;
        fn get_delegate( delegate_account: AccountId32 ) -> Option<DelegateInfo<AccountId32>>;
        fn get_delegated( delegatee_account: AccountId32 ) -> Vec<(DelegateInfo<AccountId32>, (Compact<NetUid>, Compact<AlphaBalance>))>;
    }

    pub trait NeuronInfoRuntimeApi {
        fn get_neurons(netuid: NetUid) -> Vec<NeuronInfo<AccountId32>>;
        fn get_neuron(netuid: NetUid, uid: u16) -> Option<NeuronInfo<AccountId32>>;
        fn get_neurons_lite(netuid: NetUid) -> Vec<NeuronInfoLite<AccountId32>>;
        fn get_neuron_lite(netuid: NetUid, uid: u16) -> Option<NeuronInfoLite<AccountId32>>;
    }

    pub trait SubnetInfoRuntimeApi {
        fn get_subnet_info(netuid: NetUid) -> Option<SubnetInfo<AccountId32>>;
        fn get_subnets_info() -> Vec<Option<SubnetInfo<AccountId32>>>;
        fn get_subnet_info_v2(netuid: NetUid) -> Option<SubnetInfov2<AccountId32>>;
        fn get_subnets_info_v2() -> Vec<Option<SubnetInfov2<AccountId32>>>;
        #[deprecated(note = "Use `get_subnet_hyperparams_v3` instead.")]
        fn get_subnet_hyperparams(netuid: NetUid) -> Option<SubnetHyperparams>;
        #[deprecated(note = "Use `get_subnet_hyperparams_v3` instead.")]
        fn get_subnet_hyperparams_v2(netuid: NetUid) -> Option<SubnetHyperparamsV2>;
        #[api_version(2)]
        fn get_subnet_hyperparams_v3(netuid: NetUid) -> Option<SubnetHyperparamsV3>;
        fn get_all_dynamic_info() -> Vec<Option<DynamicInfo<AccountId32>>>;
        fn get_all_metagraphs() -> Vec<Option<Metagraph<AccountId32>>>;
        fn get_metagraph(netuid: NetUid) -> Option<Metagraph<AccountId32>>;
        fn get_all_mechagraphs() -> Vec<Option<Metagraph<AccountId32>>>;
        fn get_mechagraph(netuid: NetUid, mecid: MechId) -> Option<Metagraph<AccountId32>>;
        fn get_dynamic_info(netuid: NetUid) -> Option<DynamicInfo<AccountId32>>;
        fn get_subnet_state(netuid: NetUid) -> Option<SubnetState<AccountId32>>;
        fn get_selective_metagraph(netuid: NetUid, metagraph_indexes: Vec<u16>) -> Option<SelectiveMetagraph<AccountId32>>;
        fn get_coldkey_auto_stake_hotkey(coldkey: AccountId32, netuid: NetUid) -> Option<AccountId32>;
        fn get_selective_mechagraph(netuid: NetUid, subid: MechId, metagraph_indexes: Vec<u16>) -> Option<SelectiveMetagraph<AccountId32>>;
        fn get_subnet_to_prune() -> Option<NetUid>;
        fn get_subnet_account_id(netuid: NetUid) -> Option<AccountId32>;
        fn get_next_epoch_start_block(netuid: NetUid) -> Option<u64>;
        fn get_block_emission() -> TaoBalance;
    }

    pub trait StakeInfoRuntimeApi {
        fn get_stake_info_for_coldkey( coldkey_account: AccountId32 ) -> Vec<StakeInfo<AccountId32>>;
        fn get_stake_info_for_coldkeys( coldkey_accounts: Vec<AccountId32> ) -> Vec<(AccountId32, Vec<StakeInfo<AccountId32>>)>;
        fn get_stake_info_for_hotkey_coldkey_netuid( hotkey_account: AccountId32, coldkey_account: AccountId32, netuid: NetUid ) -> Option<StakeInfo<AccountId32>>;
        fn get_stake_availability_for_coldkeys( coldkey_accounts: Vec<AccountId32>, netuids: Option<Vec<NetUid>> ) -> BTreeMap<AccountId32, BTreeMap<NetUid, StakeAvailability>>;
        fn get_stake_fee( origin: Option<(AccountId32, NetUid)>, origin_coldkey_account: AccountId32, destination: Option<(AccountId32, NetUid)>, destination_coldkey_account: AccountId32, amount: u64 ) -> u64;
        fn get_coldkey_lock(coldkey: AccountId32, netuid: NetUid) -> Option<LockState>;
        fn get_hotkey_conviction(hotkey: AccountId32, netuid: NetUid) -> U64F64;
        fn get_most_convicted_hotkey_on_subnet(netuid: NetUid) -> Option<AccountId32>;
    }

    pub trait SubnetRegistrationRuntimeApi {
        fn get_network_registration_cost() -> TaoBalance;
    }

    pub trait ProxyFilterRuntimeApi {
        fn get_proxy_types() -> Vec<ProxyTypeInfo>;
        fn get_proxy_filters(proxy_types: Option<Vec<u8>>) -> Vec<ProxyFilterInfo>;
    }

    pub trait BetaBasketRuntimeApi {
        /// Total TAO a coldkey would realize by redeeming all its root beta baskets (marked).
        fn get_root_basket_owed(coldkey: AccountId32) -> TaoBalance;
        /// TAO a coldkey would realize by redeeming its owed shares on one validator (marked).
        fn get_basket_payout(hotkey: AccountId32, coldkey: AccountId32) -> TaoBalance;
        /// A validator's beta basket net asset value, in TAO (marked).
        fn get_validator_basket_nav(hotkey: AccountId32) -> TaoBalance;
        /// A validator's basket breakdown: (subnet, alpha held, TAO value) per subnet.
        fn get_validator_basket(hotkey: AccountId32) -> Vec<(NetUid, AlphaBalance, TaoBalance)>;
        /// Network-wide total beta basket NAV across all validators, in TAO (marked).
        fn get_root_basket_total_nav() -> TaoBalance;
        /// Full explorer-facing summary of one validator's basket: NAV (realizable and spot),
        /// shares, lifetime deposit/redemption counters, and per-subnet holdings.
        fn get_validator_basket_summary(hotkey: AccountId32) -> BasketSummary<AccountId32>;
        /// Summaries for every validator with an active basket (network-wide leaderboard).
        fn get_all_validator_baskets() -> Vec<BasketSummary<AccountId32>>;
        /// A staker's positions across all its validators: (hotkey, owed shares, payout TAO).
        fn get_root_basket_positions(coldkey: AccountId32) -> Vec<(AccountId32, u64, TaoBalance)>;
        /// One staker's share-denominated position on one validator: owed shares, outstanding
        /// supply, fund NAV, and the position's realizable and spot TAO values. `None` when
        /// the staker has no owed shares there.
        #[api_version(2)]
        fn get_basket_position(hotkey: AccountId32, coldkey: AccountId32) -> Option<BasketPosition<AccountId32>>;
        /// A coldkey's full basket portfolio: one share-denominated position per validator
        /// on which it has owed shares.
        #[api_version(2)]
        fn get_root_basket_portfolio(coldkey: AccountId32) -> Vec<BasketPosition<AccountId32>>;
        /// One fund's standardized pricing snapshot (index-spliced display price,
        /// total-return stake price, staker yield, published index levels), or `None`
        /// when the hotkey has no outstanding shares. The single source of truth every
        /// consumer should display. Reads the published index snapshot in O(1) and
        /// scans only this fund's holdings.
        #[api_version(3)]
        fn get_beta_pricing(hotkey: AccountId32) -> Option<BetaPricing<AccountId32>>;
        /// One bounded page of pricing snapshots for funds with outstanding shares, all
        /// marked against the same published index snapshot. `limit` is clamped to a
        /// hard per-call cap (0 = full page); the returned `next` cursor resumes the
        /// enumeration (`None` when complete), so the full leaderboard is a short loop
        /// of bounded calls instead of one unbounded scan.
        #[api_version(3)]
        fn get_all_beta_pricing(start_after: Option<AccountId32>, limit: u32) -> BetaPricingPage<AccountId32>;
        /// The published `(bag index, stake index)` levels: the chained NAV-weighted
        /// display-price index (mix performance, flow-neutral) and the chained
        /// total-return stake index (what τ1 staked in the average fund became),
        /// maintained by the background sweep at realizable marks.
        #[api_version(3)]
        fn get_beta_index() -> (U64F64, U64F64);
        /// One staker's display-denominated β position on one validator
        /// (`display_beta * display_price` = spot value; `value_tao` = what a claim
        /// pays), or `None` when the staker has no owed β there.
        #[api_version(3)]
        fn get_beta_position(hotkey: AccountId32, coldkey: AccountId32) -> Option<BetaPosition<AccountId32>>;
        /// A coldkey's full display-denominated β portfolio, one position per validator
        /// with owed β, all marked against the same published index snapshot.
        #[api_version(3)]
        fn get_beta_portfolio(coldkey: AccountId32) -> Vec<BetaPosition<AccountId32>>;
        /// One fund's `swap_basket` trading status: the network-wide and per-hotkey gates
        /// plus the turnover window a trade at the current block would be charged to.
        #[api_version(4)]
        fn get_basket_trading_status(hotkey: AccountId32) -> BasketTradingStatus;
        /// What `claim_root_with_hotkey` would do now for this staker with the dust rules
        /// applied: full entitlement, the part a claim pays, rows sold vs skipped. `None`
        /// when the staker has no owed shares on the validator.
        #[api_version(5)]
        fn get_basket_claim_preview(hotkey: AccountId32, coldkey: AccountId32) -> Option<BasketClaimPreview<AccountId32>>;
        /// The same for every validator a coldkey-wide `claim_root` would touch.
        #[api_version(5)]
        fn get_root_basket_claim_previews(coldkey: AccountId32) -> Vec<BasketClaimPreview<AccountId32>>;
    }
}
