//! Beta basket: validator-directed rebalancing (`swap_basket`).
//!
//! Trades change only the fund's composition. Shares, the claimable rate, and every
//! staker's watermark are untouched; NAV moves only by fees and slippage; root reserves
//! stay in lockstep; the block author receives the AMM fee; both legs are booked as
//! protocol flow. Every gate, guardrail, and rollback path is pinned here.

#![allow(
    clippy::arithmetic_side_effects,
    clippy::expect_used,
    clippy::indexing_slicing,
    clippy::unwrap_used
)]

use crate::CheckColdkeySwap;
use crate::extensions::SubtensorTransactionExtension;
use crate::migrations::migrate_seed_beta_basket::kickoff_seed_beta_basket_v2;
use crate::tests::claim_root::{
    escrow_alpha, flush_baskets, fund_pool, fund_shares, register_on_root, root_stake_of,
    zero_claim_threshold,
};
use crate::tests::mock::*;
use crate::{
    BASKET_TRADE_REFILL_BLOCKS, BasketClaimed, BasketConcentrationCap, BasketDailyTurnoverCap,
    BasketLiquidityCap, BasketRate, BasketShares, BasketTradeBucket, BasketTradingEnabled,
    BasketTradingFrozen, ColdkeySwapAnnouncements, DEFAULT_BASKET_DAILY_TURNOVER_CAP,
    DefaultMinStake, Error, Event, MAX_BASKET_SWAP_LEGS, MIN_BASKET_TRADE_TAO, NetworksAdded,
    SubnetAlphaIn, SubnetAlphaOut, SubnetFastMovingPrice, SubnetMovingPrice, SubnetProtocolFlow,
    SubnetTAO, SubnetTaoFlow, SubtokenEnabled, TotalStake, Uids,
};
use codec::Encode;
use frame_support::assert_ok;
use frame_support::dispatch::DispatchResultWithPostInfo;
use frame_support::traits::{ConstU32, ExtendedDispatchable, Get};
use frame_support::weights::Weight;
use sp_core::U256;
use sp_runtime::{
    BoundedVec,
    traits::{DispatchInfoOf, Hash, TransactionExtension, TxBaseImplication},
    transaction_validity::{TransactionSource, TransactionValidityError, ValidTransaction},
};
use substrate_fixed::types::{I96F32, U64F64};
use subtensor_runtime_common::CustomTransactionError;
use subtensor_runtime_common::{AlphaBalance, NetUid, TaoBalance, Token};
use subtensor_swap_interface::SwapHandler;

type HashingOf<T> = <T as frame_system::Config>::Hashing;

/// Economic bound: a trade may only cost AMM fees and slippage, so NAV must stay within
/// this percentage of its pre-trade value on deep pools.
const FEE_TOLERANCE_PCT: u64 = 5;

/// Dividend credited to the fund in the standard playground (alpha on subnet A, price ~1).
const DIVIDEND: u64 = 25_000_000_000;

/// A trade comfortably above `DefaultMinStake` (0.002 TAO in the mock) and well inside the
/// default 10% turnover budget of a `DIVIDEND`-sized fund.
const TRADE: u64 = 1_000_000_000;

struct Fund {
    /// Owns `hotkey`; the account that signs trades.
    coldkey: U256,
    /// Root-registered validator whose basket is traded.
    hotkey: U256,
    /// Root staker entitled to the fund's dividends.
    staker: U256,
    /// Dividend origin; the fund's initial holding lives here.
    netuid_a: NetUid,
    /// Second deep pool to trade into.
    netuid_b: NetUid,
}

/// A root validator whose fund holds `DIVIDEND` alpha on subnet A, a second deep pool B,
/// EMA prices pinned at 1.0, trading enabled, and the turnover budget lifted to 100% so
/// happy-path tests can move whole holdings. Guardrail tests tighten what they need.
fn setup_fund() -> Fund {
    let coldkey = U256::from(1001);
    let hotkey = U256::from(1002);
    let staker = U256::from(1003);
    let owner_b = U256::from(2001);
    let hotkey_b = U256::from(2002);

    let netuid_a = add_dynamic_network(&hotkey, &coldkey);
    let netuid_b = add_dynamic_network(&hotkey_b, &owner_b);
    remove_owner_registration_stake(netuid_a);
    fund_pool(netuid_a);
    fund_pool(netuid_b);
    // Keep the shared pool deep enough that moving the 25 TAO fixture holding remains
    // inside the 2% execution band. The production-scale minimum below should not make
    // unrelated guardrail tests fail because of fixture slippage.
    for netuid in [netuid_a, netuid_b] {
        let reserve = 1_000_000_000_000_000u64;
        SubnetTAO::<Test>::insert(netuid, TaoBalance::from(reserve));
        SubnetAlphaIn::<Test>::insert(netuid, AlphaBalance::from(reserve));
        let account = SubtensorModule::get_subnet_account_id(netuid).unwrap();
        add_balance_to_coldkey_account(&account, TaoBalance::from(reserve));
    }
    SubnetMovingPrice::<Test>::insert(netuid_a, I96F32::from_num(1));
    SubnetMovingPrice::<Test>::insert(netuid_b, I96F32::from_num(1));
    SubnetFastMovingPrice::<Test>::insert(netuid_a, U64F64::from_num(1));
    SubnetFastMovingPrice::<Test>::insert(netuid_b, U64F64::from_num(1));

    SubtensorModule::set_tao_weight(u64::MAX);
    zero_claim_threshold();

    mock_increase_stake_for_hotkey_and_coldkey_on_subnet(
        &hotkey,
        &staker,
        NetUid::ROOT,
        2_000_000u64.into(),
    );
    mock_increase_stake_for_hotkey_and_coldkey_on_subnet(
        &hotkey,
        &coldkey,
        netuid_a,
        10_000_000u64.into(),
    );
    register_on_root(&hotkey, 0);

    SubtensorModule::distribute_emission(
        netuid_a,
        AlphaBalance::ZERO,
        AlphaBalance::ZERO,
        DIVIDEND.into(),
        AlphaBalance::ZERO,
    );
    flush_baskets();
    assert!(escrow_alpha(&hotkey, netuid_a) > 0);
    assert!(fund_shares(&hotkey) > 0);

    BasketTradingEnabled::<Test>::put(true);
    BasketDailyTurnoverCap::<Test>::put(u16::MAX);

    Fund {
        coldkey,
        hotkey,
        staker,
        netuid_a,
        netuid_b,
    }
}

/// A trade with no caller floor (`min_amount_out = 0`): the protocol band alone decides.
fn swap(fund: &Fund, origin: NetUid, dest: NetUid, amount: u64) -> DispatchResultWithPostInfo {
    swap_with_min(fund, origin, dest, amount, 0)
}

fn swap_with_min(
    fund: &Fund,
    origin: NetUid,
    dest: NetUid,
    amount: u64,
    min_amount_out: u64,
) -> DispatchResultWithPostInfo {
    SubtensorModule::swap_basket(
        RuntimeOrigin::signed(fund.coldkey),
        fund.hotkey,
        origin,
        dest,
        amount.into(),
        min_amount_out,
    )
}

fn swap_many(
    fund: &Fund,
    legs: Vec<(NetUid, NetUid, AlphaBalance, u64)>,
) -> DispatchResultWithPostInfo {
    let legs: BoundedVec<_, ConstU32<MAX_BASKET_SWAP_LEGS>> =
        legs.try_into().expect("test batch is bounded");
    SubtensorModule::swap_basket_many(RuntimeOrigin::signed(fund.coldkey), fund.hotkey, legs)
}

fn validate_basket_call(
    fund: &Fund,
    call: &RuntimeCall,
) -> Result<ValidTransaction, TransactionValidityError> {
    validate_basket_call_as(fund.coldkey, call)
}

fn validate_basket_call_as(
    signer: U256,
    call: &RuntimeCall,
) -> Result<ValidTransaction, TransactionValidityError> {
    SubtensorTransactionExtension::<Test>::new()
        .validate(
            RuntimeOrigin::signed(signer),
            call,
            &DispatchInfoOf::<RuntimeCall>::default(),
            0,
            (),
            &TxBaseImplication(()),
            TransactionSource::External,
        )
        .map(|(validity, _, _)| validity)
}

fn nav(hotkey: &U256) -> u64 {
    SubtensorModule::get_validator_basket_nav_tao(hotkey).to_u64()
}

/// The NAV the turnover budget and the concentration cap are measured against.
fn guarded_nav(hotkey: &U256) -> u64 {
    SubtensorModule::get_validator_basket_guarded_nav_tao(hotkey).to_u64()
}

fn author_balance() -> u64 {
    SubtensorModule::get_coldkey_balance(&U256::from(MOCK_BLOCK_BUILDER)).to_u64()
}

/// Refill the fund's turnover bucket so consecutive whole-holding trades in one test are
/// not limited by the budget (budget behaviour has its own tests).
fn refill_turnover_bucket(hotkey: &U256) {
    BasketTradeBucket::<Test>::remove(hotkey);
}

/// `(alpha_sold, tao_mid, alpha_bought)` of the most recent `BasketSwapped` event.
fn last_swap_event() -> (u64, u64, u64) {
    System::events()
        .iter()
        .rev()
        .find_map(|record| match &record.event {
            RuntimeEvent::SubtensorModule(Event::BasketSwapped {
                alpha_sold,
                tao_mid,
                alpha_bought,
                ..
            }) => Some((alpha_sold.to_u64(), tao_mid.to_u64(), alpha_bought.to_u64())),
            _ => None,
        })
        .expect("a BasketSwapped event was emitted")
}

/// Snapshot of everything a trade must leave untouched.
#[derive(PartialEq, Debug)]
struct Entitlements {
    shares: u64,
    rate: I96F32,
    claimed: i128,
    owed: u64,
    root_stake: u64,
}

fn entitlements(fund: &Fund) -> Entitlements {
    Entitlements {
        shares: fund_shares(&fund.hotkey),
        rate: BasketRate::<Test>::get(fund.hotkey),
        claimed: BasketClaimed::<Test>::get(fund.hotkey, fund.staker),
        owed: SubtensorModule::get_basket_owed_shares(&fund.hotkey, &fund.staker),
        root_stake: root_stake_of(&fund.hotkey, &fund.staker),
    }
}

fn assert_nav_within_fees(before: u64, after: u64) {
    assert!(
        after <= before,
        "a trade cannot create value: {before} -> {after}"
    );
    assert!(
        after >= before * (100 - FEE_TOLERANCE_PCT) / 100,
        "a trade may only cost fees and slippage: {before} -> {after}"
    );
}

// =============================================================================
// Happy paths
// =============================================================================

/// Alpha -> alpha: the holding moves, entitlements are untouched, NAV moves only by fees,
/// TotalStake drops by exactly the block author's fee, the event names both legs.
#[test]
fn test_swap_basket_alpha_to_alpha_is_composition_only() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let before = entitlements(&fund);
        let nav_before = nav(&fund.hotkey);
        let ts_before = TotalStake::<Test>::get().to_u64();
        let author_before = author_balance();

        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));

        let (alpha_sold, tao_mid, alpha_bought) = last_swap_event();
        assert_eq!(alpha_sold, TRADE);
        assert!(tao_mid > 0 && tao_mid <= TRADE, "tao_mid = {tao_mid}");
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), held - TRADE);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), alpha_bought);
        assert!(alpha_bought > 0);

        assert_eq!(entitlements(&fund), before);
        assert_nav_within_fees(nav_before, nav(&fund.hotkey));

        // The block author is paid on both legs and neither fee is stake: the sell leg's
        // fee is alpha sold fee-free for TAO that leaves the pool, and the buy leg's fee is
        // TAO that never enters the destination reserve. `TotalStake` tracks the reserves,
        // so it drops by exactly what the author received. The sell-leg fee is what the
        // origin pool booked as protocol outflow beyond `tao_mid`.
        let author_fee = author_balance() - author_before;
        assert!(
            author_fee > 0,
            "the block author must receive the swap fees"
        );
        let sell_fee_outflow = (-SubnetProtocolFlow::<Test>::get(fund.netuid_a)) as u64 - tao_mid;
        assert!(sell_fee_outflow > 0 && sell_fee_outflow < author_fee);
        assert_eq!(TotalStake::<Test>::get().to_u64(), ts_before - author_fee);
    });
}

/// Alpha -> TAO (destination 0): the proceeds become root cash 1:1, the root reserves are
/// credited by exactly `tao_mid`, and the cash slot is worth exactly its face value.
#[test]
fn test_swap_basket_alpha_to_root_credits_reserves_in_lockstep() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let root_tao_before = SubnetTAO::<Test>::get(NetUid::ROOT).to_u64();
        let root_alpha_out_before = SubnetAlphaOut::<Test>::get(NetUid::ROOT).to_u64();
        let nav_before = nav(&fund.hotkey);
        let before = entitlements(&fund);

        // The whole holding.
        assert_ok!(swap(&fund, fund.netuid_a, NetUid::ROOT, held));

        let (alpha_sold, tao_mid, alpha_bought) = last_swap_event();
        assert_eq!(alpha_sold, held);
        assert_eq!(alpha_bought, tao_mid, "root cash is TAO 1:1");
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), 0);
        assert_eq!(escrow_alpha(&fund.hotkey, NetUid::ROOT), tao_mid);
        assert_eq!(
            SubnetTAO::<Test>::get(NetUid::ROOT).to_u64(),
            root_tao_before + tao_mid
        );
        assert_eq!(
            SubnetAlphaOut::<Test>::get(NetUid::ROOT).to_u64(),
            root_alpha_out_before + tao_mid
        );
        assert_eq!(nav(&fund.hotkey), tao_mid, "cash values at face");
        assert_eq!(entitlements(&fund), before);
        assert_nav_within_fees(nav_before, nav(&fund.hotkey));
    });
}

/// TAO -> alpha (origin 0): the cash slot is debited, the root reserves unwind exactly to
/// where they started, and no block-author fee is taken on the root leg.
#[test]
fn test_swap_basket_root_to_alpha_debits_reserves_in_lockstep() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let root_tao_start = SubnetTAO::<Test>::get(NetUid::ROOT).to_u64();
        let root_alpha_out_start = SubnetAlphaOut::<Test>::get(NetUid::ROOT).to_u64();
        assert_ok!(swap(
            &fund,
            fund.netuid_a,
            NetUid::ROOT,
            escrow_alpha(&fund.hotkey, fund.netuid_a)
        ));
        let cash = escrow_alpha(&fund.hotkey, NetUid::ROOT);
        assert!(cash > 0);
        refill_turnover_bucket(&fund.hotkey);

        let before = entitlements(&fund);
        let nav_before = nav(&fund.hotkey);
        let ts_before = TotalStake::<Test>::get().to_u64();
        let author_before = author_balance();

        assert_ok!(swap(&fund, NetUid::ROOT, fund.netuid_b, cash));

        let (alpha_sold, tao_mid, alpha_bought) = last_swap_event();
        assert_eq!(alpha_sold, cash);
        assert_eq!(tao_mid, cash, "selling cash is TAO 1:1 with no fee");
        assert_eq!(escrow_alpha(&fund.hotkey, NetUid::ROOT), 0);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), alpha_bought);
        assert!(alpha_bought > 0);
        assert_eq!(
            SubnetTAO::<Test>::get(NetUid::ROOT).to_u64(),
            root_tao_start
        );
        assert_eq!(
            SubnetAlphaOut::<Test>::get(NetUid::ROOT).to_u64(),
            root_alpha_out_start
        );
        // Root leg is fee-free; the buy leg's fee goes to the author and never enters the
        // destination reserve, so `TotalStake` drops by exactly that fee.
        let buy_fee = author_balance() - author_before;
        assert!(buy_fee > 0, "buy-leg fee goes to the author");
        assert_eq!(TotalStake::<Test>::get().to_u64(), ts_before - buy_fee);
        assert_eq!(entitlements(&fund), before);
        assert_nav_within_fees(nav_before, nav(&fund.hotkey));
    });
}

/// Both legs are booked as protocol flow, never user flow: the sell leg is an outflow of
/// `tao_mid` plus the author fee, the buy leg an inflow bounded by `tao_mid`.
#[test]
fn test_swap_basket_books_protocol_flow_not_user_flow() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        assert_eq!(SubnetProtocolFlow::<Test>::get(fund.netuid_a), 0);
        assert_eq!(SubnetProtocolFlow::<Test>::get(fund.netuid_b), 0);
        let user_a = SubnetTaoFlow::<Test>::get(fund.netuid_a);
        let user_b = SubnetTaoFlow::<Test>::get(fund.netuid_b);
        let author_before = author_balance();

        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));

        let (_, tao_mid, _) = last_swap_event();
        let author_fee = (author_balance() - author_before) as i64;
        let flow_a = SubnetProtocolFlow::<Test>::get(fund.netuid_a);
        let flow_b = SubnetProtocolFlow::<Test>::get(fund.netuid_b);
        // Sell leg: outflow of the TAO through the middle plus the author's fee share.
        let sell_fee_outflow = -flow_a - tao_mid as i64;
        assert!(
            sell_fee_outflow > 0,
            "sell outflow must include the author fee: {flow_a}"
        );
        assert!(
            sell_fee_outflow < author_fee,
            "author is also paid on the buy leg"
        );
        // Buy leg: inflow is what entered the pool, fee excluded.
        assert!(
            flow_b > 0 && flow_b < tao_mid as i64,
            "buy inflow = {flow_b}"
        );
        assert!(tao_mid as i64 - flow_b < author_fee);

        assert_eq!(SubnetTaoFlow::<Test>::get(fund.netuid_a), user_a);
        assert_eq!(SubnetTaoFlow::<Test>::get(fund.netuid_b), user_b);
    });
}

/// After a rebalance the staker still redeems ~the same value: composition is not
/// entitlement.
#[test]
fn test_swap_basket_then_claim_pays_the_same_value() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let nav_before = nav(&fund.hotkey);
        let owed_before = SubtensorModule::get_basket_owed_shares(&fund.hotkey, &fund.staker);

        assert_ok!(swap(
            &fund,
            fund.netuid_a,
            fund.netuid_b,
            escrow_alpha(&fund.hotkey, fund.netuid_a)
        ));
        assert_eq!(
            SubtensorModule::get_basket_owed_shares(&fund.hotkey, &fund.staker),
            owed_before
        );

        let root_before = root_stake_of(&fund.hotkey, &fund.staker);
        assert_ok!(SubtensorModule::claim_root_with_hotkey(
            RuntimeOrigin::signed(fund.staker),
            fund.hotkey
        ));
        let gain = root_stake_of(&fund.hotkey, &fund.staker) - root_before;
        assert_nav_within_fees(nav_before, gain);
    });
}

/// The actual weight scales with the fund's holding count and never exceeds the declared
/// 256-row cap.
#[test]
fn test_swap_basket_post_dispatch_weight_is_bounded() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let post = swap(&fund, fund.netuid_a, fund.netuid_b, TRADE).expect("trade succeeds");
        let actual = post.actual_weight.expect("trade reports its actual weight");
        // Two rows after the trade (A remainder + B).
        assert_eq!(actual, SubtensorModule::swap_basket_weight(2));
        assert!(actual.all_lt(SubtensorModule::swap_basket_weight(256)));
    });
}

#[test]
fn test_swap_basket_many_executes_legs_with_one_initial_sweep() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let origin_before = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let post = swap_many(
            &fund,
            vec![
                (
                    fund.netuid_a,
                    fund.netuid_b,
                    AlphaBalance::from(2 * TRADE),
                    0,
                ),
                (fund.netuid_b, NetUid::ROOT, AlphaBalance::from(TRADE), 0),
            ],
        )
        .expect("both legs succeed");

        assert_eq!(
            escrow_alpha(&fund.hotkey, fund.netuid_a),
            origin_before - 2 * TRADE
        );
        assert!(escrow_alpha(&fund.hotkey, fund.netuid_b) > 0);
        assert!(escrow_alpha(&fund.hotkey, NetUid::ROOT) > 0);
        assert_eq!(
            post.actual_weight,
            Some(SubtensorModule::swap_basket_many_weight(1, 2))
        );
        let swaps = System::events()
            .iter()
            .filter(|record| {
                matches!(
                    record.event,
                    RuntimeEvent::SubtensorModule(Event::BasketSwapped { .. })
                )
            })
            .count();
        assert_eq!(swaps, 2);
    });
}

#[test]
fn test_swap_basket_many_rolls_back_all_trade_legs_on_failure() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let origin_before = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let result = swap_many(
            &fund,
            vec![
                (
                    fund.netuid_a,
                    fund.netuid_b,
                    AlphaBalance::from(2 * TRADE),
                    0,
                ),
                (fund.netuid_b, NetUid::ROOT, AlphaBalance::from(DIVIDEND), 0),
            ],
        );

        frame_support::assert_err_ignore_postinfo!(result, Error::<Test>::NotEnoughStakeToWithdraw);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), origin_before);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), 0);
        assert_eq!(escrow_alpha(&fund.hotkey, NetUid::ROOT), 0);
        assert!(!System::events().iter().any(|record| matches!(
            record.event,
            RuntimeEvent::SubtensorModule(Event::BasketSwapped { .. })
        )));
    });
}

#[test]
fn test_swap_basket_many_rejects_an_empty_batch() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        frame_support::assert_err_ignore_postinfo!(
            swap_many(&fund, Vec::new()),
            Error::<Test>::BasketSwapBatchEmpty
        );
    });
}

// =============================================================================
// Gates and errors
// =============================================================================

#[test]
fn test_swap_basket_rejects_when_trading_disabled() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        BasketTradingEnabled::<Test>::put(false);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTradingDisabled
        );
    });
}

#[test]
fn test_swap_basket_rejects_when_frozen() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        BasketTradingFrozen::<Test>::insert(fund.hotkey, ());
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTradingFrozen
        );
        BasketTradingFrozen::<Test>::remove(fund.hotkey);
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
    });
}

#[test]
fn test_swap_basket_rejects_same_subnet() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_a, TRADE),
            Error::<Test>::BasketSameSubnet
        );
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, NetUid::ROOT, NetUid::ROOT, TRADE),
            Error::<Test>::BasketSameSubnet
        );
    });
}

#[test]
fn test_swap_basket_rejects_non_owner_coldkey() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let stranger = U256::from(777);
        crate::assert_noop_ignore_postinfo!(
            SubtensorModule::swap_basket(
                RuntimeOrigin::signed(stranger),
                fund.hotkey,
                fund.netuid_a,
                fund.netuid_b,
                TRADE.into(),
                0,
            ),
            Error::<Test>::NonAssociatedColdKey
        );
        // A hotkey with no account at all is also "not owned".
        crate::assert_noop_ignore_postinfo!(
            SubtensorModule::swap_basket(
                RuntimeOrigin::signed(fund.coldkey),
                U256::from(778),
                fund.netuid_a,
                fund.netuid_b,
                TRADE.into(),
                0,
            ),
            Error::<Test>::NonAssociatedColdKey
        );
    });
}

#[test]
fn test_swap_basket_rejects_hotkey_not_on_root() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        Uids::<Test>::remove(NetUid::ROOT, fund.hotkey);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::HotKeyNotRegisteredInSubNet
        );
    });
}

#[test]
fn test_swap_basket_rejects_while_seed_migration_in_progress() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        kickoff_seed_beta_basket_v2::<Test>();
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BetaBasketSeedInProgress
        );
    });
}

/// The `CheckColdkeySwap` dispatch extension refuses the trade while the signing coldkey
/// has a swap announced (the same guard every other signed call gets).
#[test]
fn test_swap_basket_rejects_while_coldkey_swap_announced() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let call = RuntimeCall::SubtensorModule(crate::Call::swap_basket {
            hotkey: fund.hotkey,
            origin_netuid: fund.netuid_a,
            destination_netuid: fund.netuid_b,
            amount: TRADE.into(),
            min_amount_out: 0,
        });
        let dispatch = |call: RuntimeCall| {
            <CheckColdkeySwap<Test> as ExtendedDispatchable<RuntimeCall>>::dispatch_with_extension(
                RuntimeOrigin::signed(fund.coldkey),
                call,
            )
        };

        let hash = HashingOf::<Test>::hash_of(&U256::from(42));
        ColdkeySwapAnnouncements::<Test>::insert(fund.coldkey, (System::block_number(), hash));
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        assert_eq!(
            dispatch(call.clone()).unwrap_err().error,
            Error::<Test>::ColdkeySwapAnnounced.into()
        );
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), held);

        ColdkeySwapAnnouncements::<Test>::remove(fund.coldkey);
        assert_ok!(dispatch(call));
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), held - TRADE);
    });
}

#[test]
fn test_swap_basket_rejects_nonexistent_subnets() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let missing = NetUid::from(99u16);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, missing, TRADE),
            Error::<Test>::SubnetNotExists
        );
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, missing, fund.netuid_a, TRADE),
            Error::<Test>::SubnetNotExists
        );
    });
}

#[test]
fn test_swap_basket_rejects_subtoken_disabled_destination() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        SubtokenEnabled::<Test>::insert(fund.netuid_b, false);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SubtokenDisabled
        );
    });
}

#[test]
fn test_swap_basket_rejects_zero_and_dust_amounts() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, 0),
            Error::<Test>::AmountTooLow
        );
        // Positive, but the TAO through the middle lands below `DefaultMinStake`.
        let dust = DefaultMinStake::<Test>::get().to_u64() / 2;
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, dust),
            Error::<Test>::AmountTooLow
        );
        // A refill-driven 0.08 TAO trade clears the general staking minimum but is still
        // uneconomic next to the transaction fee (about 0.006 TAO).
        let fee_draining_dust = 80_000_000;
        assert!(fee_draining_dust > DefaultMinStake::<Test>::get().to_u64());
        assert!(fee_draining_dust < MIN_BASKET_TRADE_TAO);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, fee_draining_dust),
            Error::<Test>::AmountTooLow
        );
    });
}

#[test]
fn transaction_validation_rejects_fee_draining_basket_calls() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let fee_draining_dust = 80_000_000;
        let reserves_before = (
            SubnetTAO::<Test>::get(fund.netuid_a),
            SubnetAlphaIn::<Test>::get(fund.netuid_a),
            SubnetAlphaOut::<Test>::get(fund.netuid_a),
        );

        let dust_call = RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
            hotkey: fund.hotkey,
            origin_netuid: fund.netuid_a,
            destination_netuid: fund.netuid_b,
            amount: fee_draining_dust.into(),
            min_amount_out: 0,
        });
        assert_eq!(
            validate_basket_call(&fund, &dust_call).unwrap_err(),
            CustomTransactionError::StakeAmountTooLow.into()
        );

        let dust_batch = RuntimeCall::SubtensorModule(SubtensorCall::swap_basket_many {
            hotkey: fund.hotkey,
            legs: vec![(
                fund.netuid_a,
                fund.netuid_b,
                AlphaBalance::from(fee_draining_dust),
                0,
            )]
            .try_into()
            .expect("one leg is bounded"),
        });
        assert_eq!(
            validate_basket_call(&fund, &dust_batch).unwrap_err(),
            CustomTransactionError::StakeAmountTooLow.into()
        );

        let economic_call = RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
            hotkey: fund.hotkey,
            origin_netuid: fund.netuid_a,
            destination_netuid: fund.netuid_b,
            amount: TRADE.into(),
            min_amount_out: 0,
        });
        assert_ok!(validate_basket_call(&fund, &economic_call));

        // Transaction validation quotes with rollback semantics; merely submitting the call
        // to the pool cannot move reserves before inclusion.
        assert_eq!(
            (
                SubnetTAO::<Test>::get(fund.netuid_a),
                SubnetAlphaIn::<Test>::get(fund.netuid_a),
                SubnetAlphaOut::<Test>::get(fund.netuid_a),
            ),
            reserves_before
        );
    });
}

#[test]
fn transaction_validation_rejects_fee_draining_basket_calls_in_utility_wrappers() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let dust_call = RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
            hotkey: fund.hotkey,
            origin_netuid: fund.netuid_a,
            destination_netuid: fund.netuid_b,
            amount: 80_000_000u64.into(),
            min_amount_out: 0,
        });

        let wrapped_calls = [
            RuntimeCall::Utility(pallet_subtensor_utility::Call::batch {
                calls: vec![dust_call.clone()],
            }),
            RuntimeCall::Utility(pallet_subtensor_utility::Call::batch_all {
                calls: vec![dust_call.clone()],
            }),
            RuntimeCall::Utility(pallet_subtensor_utility::Call::force_batch {
                calls: vec![dust_call.clone()],
            }),
            RuntimeCall::Utility(pallet_subtensor_utility::Call::if_else {
                main: Box::new(RuntimeCall::System(frame_system::Call::remark {
                    remark: vec![],
                })),
                fallback: Box::new(dust_call),
            }),
        ];

        for wrapped in wrapped_calls {
            assert_eq!(
                validate_basket_call(&fund, &wrapped).unwrap_err(),
                CustomTransactionError::StakeAmountTooLow.into()
            );
        }
    });
}

#[test]
fn transaction_validation_uses_proxy_real_account_for_basket_calls() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let delegate = U256::from(7001);

        let wrap_proxy = |amount: u64| {
            RuntimeCall::Proxy(pallet_subtensor_proxy::Call::proxy {
                real: fund.coldkey,
                force_proxy_type: Some(subtensor_runtime_common::ProxyType::BasketTrading),
                call: Box::new(RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
                    hotkey: fund.hotkey,
                    origin_netuid: fund.netuid_a,
                    destination_netuid: fund.netuid_b,
                    amount: amount.into(),
                    min_amount_out: 0,
                })),
            })
        };

        // The delegate does not own the hotkey. Acceptance of the economic call proves the
        // validator applies the inner ownership checks to the proxy's real account.
        assert_ok!(validate_basket_call_as(delegate, &wrap_proxy(TRADE)));
        assert_eq!(
            validate_basket_call_as(delegate, &wrap_proxy(80_000_000)).unwrap_err(),
            CustomTransactionError::StakeAmountTooLow.into()
        );

        // Wrapper traversal composes: a proxy call nested in Utility must not restore the outer
        // delegate as the effective signer or hide the dust trade.
        let nested = RuntimeCall::Utility(pallet_subtensor_utility::Call::batch_all {
            calls: vec![wrap_proxy(80_000_000)],
        });
        assert_eq!(
            validate_basket_call_as(delegate, &nested).unwrap_err(),
            CustomTransactionError::StakeAmountTooLow.into()
        );

        let announced = RuntimeCall::Proxy(pallet_subtensor_proxy::Call::proxy_announced {
            delegate,
            real: fund.coldkey,
            force_proxy_type: Some(subtensor_runtime_common::ProxyType::BasketTrading),
            call: Box::new(RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
                hotkey: fund.hotkey,
                origin_netuid: fund.netuid_a,
                destination_netuid: fund.netuid_b,
                amount: 80_000_000u64.into(),
                min_amount_out: 0,
            })),
        });
        assert_eq!(
            validate_basket_call_as(U256::from(7002), &announced).unwrap_err(),
            CustomTransactionError::StakeAmountTooLow.into()
        );
    });
}

#[test]
fn transaction_validation_weight_accounts_for_wrapped_basket_legs() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let basket_call = RuntimeCall::SubtensorModule(SubtensorCall::swap_basket {
            hotkey: fund.hotkey,
            origin_netuid: fund.netuid_a,
            destination_netuid: fund.netuid_b,
            amount: TRADE.into(),
            min_amount_out: 0,
        });
        let empty_batch =
            RuntimeCall::Utility(pallet_subtensor_utility::Call::batch_all { calls: vec![] });
        let wrapped = RuntimeCall::Utility(pallet_subtensor_utility::Call::batch_all {
            calls: vec![basket_call.clone(), basket_call],
        });
        let extension = SubtensorTransactionExtension::<Test>::new();
        let expected = extension
            .weight(&empty_batch)
            .saturating_add(SubtensorModule::swap_basket_validation_weight().saturating_mul(2));

        assert_eq!(extension.weight(&wrapped), expected);
        assert_ok!(validate_basket_call(&fund, &wrapped));
    });
}

#[test]
fn test_swap_basket_rejects_more_than_held() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, held + 1),
            Error::<Test>::NotEnoughStakeToWithdraw
        );
        // An empty origin (no cash yet) fails the same way.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, NetUid::ROOT, fund.netuid_b, TRADE),
            Error::<Test>::NotEnoughStakeToWithdraw
        );
    });
}

// =============================================================================
// Guardrail: per-leg slippage band
// =============================================================================

/// Buy leg, EMA anchor: a pre-trade pump (spot above the moving price by more than 2%)
/// is refused before any leg runs.
#[test]
fn test_swap_basket_buy_refused_when_spot_above_ema_band() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Spot is 1.0; a moving price of 0.9 puts the ceiling at 0.918.
        SubnetMovingPrice::<Test>::insert(fund.netuid_b, I96F32::from_num(0.9));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
    });
}

/// Sell leg, EMA anchor: a pre-trade dump (spot below the moving price by more than 2%)
/// is refused.
#[test]
fn test_swap_basket_sell_refused_when_spot_below_ema_band() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Spot is 1.0; a moving price of 1.1 puts the floor at 1.078.
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(1.1));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
    });
}

/// A subnet with no moving price yet — slow or fast — cannot be traded on either leg.
#[test]
fn test_swap_basket_refused_without_moving_price() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        SubnetMovingPrice::<Test>::insert(fund.netuid_b, I96F32::from_num(0));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        SubnetMovingPrice::<Test>::insert(fund.netuid_b, I96F32::from_num(1));
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(0));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(1));

        // The fast anchor is required too: a subnet not yet updated since the fast series
        // was introduced (or never emitting) is refused on either leg.
        SubnetFastMovingPrice::<Test>::remove(fund.netuid_b);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        SubnetFastMovingPrice::<Test>::insert(fund.netuid_b, U64F64::from_num(1));
        SubnetFastMovingPrice::<Test>::remove(fund.netuid_a);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        SubnetFastMovingPrice::<Test>::insert(fund.netuid_a, U64F64::from_num(1));
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
    });
}

/// Buy leg, spot anchor: on a thin destination pool the trade's own price impact would
/// exceed 2%, so the leg cannot fill fully within the ceiling and the trade is refused.
#[test]
fn test_swap_basket_buy_refused_when_own_impact_exceeds_band() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // 10 TAO / 10 alpha: a 4 TAO buy would move the price ~96%.
        SubnetTAO::<Test>::insert(fund.netuid_b, TaoBalance::from(10_000_000u64));
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, AlphaBalance::from(10_000_000u64));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
    });
}

/// Sell leg, spot anchor: on a thin origin pool the sale's own impact exceeds 2%.
#[test]
fn test_swap_basket_sell_refused_when_own_impact_exceeds_band() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        SubnetTAO::<Test>::insert(fund.netuid_a, TaoBalance::from(10_000_000u64));
        SubnetAlphaIn::<Test>::insert(fund.netuid_a, AlphaBalance::from(10_000_000u64));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
    });
}

/// Fills that sit just inside the band on both legs pass: spot 1% away from the moving
/// price on each side, and a trade small enough to leave less than 1% of impact.
#[test]
fn test_swap_basket_fills_just_inside_band() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Sell floor = max(1.01, 1.0) * 0.98 = 0.9898 < spot; buy ceiling = min(0.99, 1.0)
        // * 1.02 = 1.0098 > spot.
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(1.01));
        SubnetMovingPrice::<Test>::insert(fund.netuid_b, I96F32::from_num(0.99));
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        let (alpha_sold, tao_mid, alpha_bought) = last_swap_event();
        assert_eq!(alpha_sold, TRADE);
        assert!(tao_mid > 0 && alpha_bought > 0);
    });
}

/// A `swap_basket` refusal after the sell leg has already executed rolls the whole trade
/// back: holdings, reserves, TotalStake, author fee, and the turnover bucket are untouched.
#[test]
fn test_swap_basket_failed_second_leg_leaves_no_partial_state() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // The sell leg on A is fine; the buy leg on a thin B fails.
        SubnetTAO::<Test>::insert(fund.netuid_b, TaoBalance::from(10_000_000u64));
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, AlphaBalance::from(10_000_000u64));

        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let tao_a = SubnetTAO::<Test>::get(fund.netuid_a);
        let alpha_in_a = SubnetAlphaIn::<Test>::get(fund.netuid_a);
        let ts = TotalStake::<Test>::get();
        let author = author_balance();
        let bucket = BasketTradeBucket::<Test>::get(fund.hotkey);
        let flow_a = SubnetProtocolFlow::<Test>::get(fund.netuid_a);
        let before = entitlements(&fund);

        assert!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE).is_err());

        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), held);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), 0);
        assert_eq!(SubnetTAO::<Test>::get(fund.netuid_a), tao_a);
        assert_eq!(SubnetAlphaIn::<Test>::get(fund.netuid_a), alpha_in_a);
        assert_eq!(TotalStake::<Test>::get(), ts);
        assert_eq!(
            author_balance(),
            author,
            "rolled-back fee must not reach the author"
        );
        assert_eq!(BasketTradeBucket::<Test>::get(fund.hotkey), bucket);
        assert_eq!(SubnetProtocolFlow::<Test>::get(fund.netuid_a), flow_a);
        assert_eq!(entitlements(&fund), before);
        assert!(!System::events().iter().any(|e| matches!(
            e.event,
            RuntimeEvent::SubtensorModule(Event::BasketSwapped { .. })
        )));
    });
}

/// Spec 469 regression (Yuma, finney v468): a `swap_basket` sized at ~1% of the destination
/// reserve with `min_amount_out = 0` is refused by the 2% protocol band (`SlippageTooHigh`)
/// after the sell leg ran and rolled back. It used to keep the 256-row declared envelope
/// (0.43 TAO quoted); it now reports the pre-checks, the flush and one trade over the
/// fund's real row count — never the envelope, never below the valuation sweep it did.
#[test]
fn regression_failed_swap_basket_pays_its_work_not_the_envelope() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // A thin destination: the trade's own impact pushes the buy leg out of the band.
        let reserve_tao = 100 * TRADE;
        SubnetTAO::<Test>::insert(fund.netuid_b, TaoBalance::from(reserve_tao));
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, AlphaBalance::from(reserve_tao));
        let rows = SubtensorModule::get_basket_holdings(&fund.hotkey).len() as u64;
        assert_eq!(rows, 1, "the fund holds A only before the trade");

        let err = swap(&fund, fund.netuid_a, fund.netuid_b, TRADE).expect_err("band refuses");
        assert_eq!(err.error, Error::<Test>::SlippageTooHigh.into());
        let actual = err
            .post_info
            .actual_weight
            .expect("a failed trade reports the weight it used");

        let precheck = SubtensorModule::swap_basket_precheck_weight();
        let one_trade = SubtensorModule::swap_basket_weight(rows);
        // Nothing was queued, so the flush contributed nothing: exactly base + scan.
        assert_eq!(actual, one_trade.saturating_add(precheck));
        assert!(
            actual.all_gte(one_trade),
            "never below the valuation sweep it did"
        );
        assert!(
            actual.ref_time() * 20 < SubtensorModule::swap_basket_declared_weight().ref_time(),
            "a failed trade over one row is a small fraction of the 256-row envelope"
        );
        assert!(!System::events().iter().any(|e| matches!(
            e.event,
            RuntimeEvent::SubtensorModule(Event::BasketSwapped { .. })
        )));

        // A successful trade still refunds to its actual row count.
        SubnetTAO::<Test>::insert(fund.netuid_b, TaoBalance::from(100_000 * TRADE));
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, AlphaBalance::from(100_000 * TRADE));
        let post = swap(&fund, fund.netuid_a, fund.netuid_b, TRADE).expect("trade succeeds");
        assert_eq!(
            post.actual_weight,
            Some(SubtensorModule::swap_basket_weight(2)),
            "two rows after the trade, no flush"
        );
    });
}

// =============================================================================
// Caller floor: `min_amount_out`
// =============================================================================

/// What one `amount` trade `origin -> dest` credits in the standard playground, learned
/// on a throwaway copy of the state so the test's own externalities stay pristine. The
/// mock is deterministic, so the same trade in the test yields exactly this.
fn quote_alpha_out(origin_is_root: bool, dest_is_root: bool, amount: u64) -> u64 {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let origin = if origin_is_root {
            NetUid::ROOT
        } else {
            fund.netuid_a
        };
        let dest = if dest_is_root {
            NetUid::ROOT
        } else {
            fund.netuid_b
        };
        assert_ok!(swap(&fund, origin, dest, amount));
        last_swap_event().2
    })
}

/// A floor at or below what the buy leg credits passes; the credited amount is the
/// post-fee alpha of the destination, exactly what the event reports.
#[test]
fn test_swap_basket_min_out_met_passes() {
    let quoted = quote_alpha_out(false, false, TRADE);
    assert!(quoted > 0 && quoted < TRADE, "quoted = {quoted}");
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Exactly at the boundary: the floor is inclusive.
        assert_ok!(swap_with_min(
            &fund,
            fund.netuid_a,
            fund.netuid_b,
            TRADE,
            quoted
        ));
        let (_, _, alpha_bought) = last_swap_event();
        assert_eq!(alpha_bought, quoted);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), quoted);

        // A looser floor on a second trade passes too (the pools moved a little against
        // the fund, so the second fill is no larger than the first).
        refill_turnover_bucket(&fund.hotkey);
        assert_ok!(swap_with_min(
            &fund,
            fund.netuid_a,
            fund.netuid_b,
            TRADE,
            quoted * 9 / 10
        ));
        let (_, _, second) = last_swap_event();
        assert!(second <= quoted && second >= quoted * 9 / 10);
    });
}

/// A floor one rao above what the buy leg credits fails with `BasketMinOutNotMet` after
/// both legs have executed, and the whole trade rolls back: holdings, reserves,
/// TotalStake, author fee, turnover bucket, protocol flow, entitlements, and no event.
/// The protocol band is unchanged: a leg that misses the band still fails with
/// `SlippageTooHigh` whatever the floor.
#[test]
fn test_swap_basket_min_out_not_met_fails_and_rolls_back() {
    let quoted = quote_alpha_out(false, false, TRADE);
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        let tao_a = SubnetTAO::<Test>::get(fund.netuid_a);
        let alpha_in_a = SubnetAlphaIn::<Test>::get(fund.netuid_a);
        let tao_b = SubnetTAO::<Test>::get(fund.netuid_b);
        let alpha_in_b = SubnetAlphaIn::<Test>::get(fund.netuid_b);
        let ts = TotalStake::<Test>::get();
        let author = author_balance();
        let bucket = BasketTradeBucket::<Test>::get(fund.hotkey);
        let flow_a = SubnetProtocolFlow::<Test>::get(fund.netuid_a);
        let flow_b = SubnetProtocolFlow::<Test>::get(fund.netuid_b);
        let before = entitlements(&fund);

        crate::assert_noop_ignore_postinfo!(
            swap_with_min(&fund, fund.netuid_a, fund.netuid_b, TRADE, quoted + 1),
            Error::<Test>::BasketMinOutNotMet
        );
        crate::assert_noop_ignore_postinfo!(
            swap_with_min(&fund, fund.netuid_a, fund.netuid_b, TRADE, u64::MAX),
            Error::<Test>::BasketMinOutNotMet
        );

        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), held);
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_b), 0);
        assert_eq!(SubnetTAO::<Test>::get(fund.netuid_a), tao_a);
        assert_eq!(SubnetAlphaIn::<Test>::get(fund.netuid_a), alpha_in_a);
        assert_eq!(SubnetTAO::<Test>::get(fund.netuid_b), tao_b);
        assert_eq!(SubnetAlphaIn::<Test>::get(fund.netuid_b), alpha_in_b);
        assert_eq!(TotalStake::<Test>::get(), ts);
        assert_eq!(
            author_balance(),
            author,
            "rolled-back fees must not reach the author"
        );
        assert_eq!(BasketTradeBucket::<Test>::get(fund.hotkey), bucket);
        assert_eq!(SubnetProtocolFlow::<Test>::get(fund.netuid_a), flow_a);
        assert_eq!(SubnetProtocolFlow::<Test>::get(fund.netuid_b), flow_b);
        assert_eq!(entitlements(&fund), before);
        assert!(!System::events().iter().any(|e| matches!(
            e.event,
            RuntimeEvent::SubtensorModule(Event::BasketSwapped { .. })
        )));

        // The band is checked inside the leg, before the floor: a thin destination pool
        // is still refused as `SlippageTooHigh`, not as a missed floor.
        SubnetTAO::<Test>::insert(fund.netuid_b, TaoBalance::from(10_000_000u64));
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, AlphaBalance::from(10_000_000u64));
        crate::assert_noop_ignore_postinfo!(
            swap_with_min(&fund, fund.netuid_a, fund.netuid_b, TRADE, u64::MAX),
            Error::<Test>::SlippageTooHigh
        );

        // Zero is "no floor": the same trade passes once the pool is deep again.
        SubnetTAO::<Test>::insert(fund.netuid_b, tao_b);
        SubnetAlphaIn::<Test>::insert(fund.netuid_b, alpha_in_b);
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        assert_eq!(last_swap_event().2, quoted);
    });
}

/// With the cash slot as destination the credited amount is TAO (rao) at 1:1 with
/// `tao_mid`, so the floor is compared in TAO units: `tao_mid` passes, `tao_mid + 1`
/// fails. With the cash slot as origin the floor is in destination alpha as usual.
#[test]
fn test_swap_basket_min_out_on_cash_slot_uses_tao_units() {
    let tao_out = quote_alpha_out(false, true, TRADE);
    assert!(tao_out > 0 && tao_out < TRADE, "tao_out = {tao_out}");
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();

        // Alpha -> cash: a floor of `TRADE` alpha-equivalents cannot be met (the sell leg
        // pays fees and slippage), one rao above the true TAO proceeds cannot either.
        crate::assert_noop_ignore_postinfo!(
            swap_with_min(&fund, fund.netuid_a, NetUid::ROOT, TRADE, tao_out + 1),
            Error::<Test>::BasketMinOutNotMet
        );
        assert_ok!(swap_with_min(
            &fund,
            fund.netuid_a,
            NetUid::ROOT,
            TRADE,
            tao_out
        ));
        let (_, tao_mid, alpha_bought) = last_swap_event();
        assert_eq!(tao_mid, tao_out);
        assert_eq!(alpha_bought, tao_out, "root cash is TAO 1:1");
        assert_eq!(escrow_alpha(&fund.hotkey, NetUid::ROOT), tao_out);

        // Cash -> alpha: the floor is destination alpha. Selling cash is fee-free and 1:1,
        // so the buy leg alone decides; `tao_out` TAO buys a little less than `tao_out`
        // alpha at price 1, and asking for exactly `tao_out` alpha is refused.
        refill_turnover_bucket(&fund.hotkey);
        crate::assert_noop_ignore_postinfo!(
            swap_with_min(&fund, NetUid::ROOT, fund.netuid_b, tao_out, tao_out),
            Error::<Test>::BasketMinOutNotMet
        );
        assert_ok!(swap_with_min(
            &fund,
            NetUid::ROOT,
            fund.netuid_b,
            tao_out,
            tao_out * 9 / 10
        ));
        let (sold, mid, bought) = last_swap_event();
        assert_eq!(sold, tao_out);
        assert_eq!(mid, tao_out);
        assert!(
            bought < tao_out && bought >= tao_out * 9 / 10,
            "bought = {bought}"
        );
        assert_eq!(escrow_alpha(&fund.hotkey, NetUid::ROOT), 0);
    });
}

// =============================================================================
// Guardrail: turnover budget
// =============================================================================

/// The TAO through the middle drains the turnover bucket, refuses when the bucket cannot
/// cover a trade, refills continuously at `budget / BASKET_TRADE_REFILL_BLOCKS` per block,
/// and clamps at one full budget.
#[test]
fn test_swap_basket_turnover_bucket_drains_refuses_and_refills() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        BasketDailyTurnoverCap::<Test>::put(DEFAULT_BASKET_DAILY_TURNOVER_CAP);
        let budget = SubtensorModule::basket_trade_budget_tao(guarded_nav(&fund.hotkey));
        // 10% of a ~100 TAO fund: two 4 TAO trades fit, a third does not.
        assert!(
            budget > 2 * TRADE && budget < 3 * TRADE,
            "budget = {budget}"
        );
        let start = System::block_number();

        // A fund that has never traded has a full bucket and no stored row.
        assert_eq!(BasketTradeBucket::<Test>::get(fund.hotkey), None);
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        assert_eq!(status.tao_available.to_u64(), budget);
        assert_eq!(status.budget_tao.to_u64(), budget);
        assert_eq!(status.refill_blocks, BASKET_TRADE_REFILL_BLOCKS);

        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        let (_, mid_1, _) = last_swap_event();
        assert_eq!(
            BasketTradeBucket::<Test>::get(fund.hotkey),
            Some((budget - mid_1, start))
        );

        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        let (_, mid_2, _) = last_swap_event();
        assert_eq!(
            BasketTradeBucket::<Test>::get(fund.hotkey),
            Some((budget - mid_1 - mid_2, start)),
            "each trade takes its tao_mid out of the bucket"
        );

        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTurnoverBudgetExceeded
        );
        // The view agrees with what a trade would be allowed right now.
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        assert_eq!(status.tao_available.to_u64(), budget - mid_1 - mid_2);
        assert!(status.enabled && !status.frozen);

        // Half a refill period later the bucket has gained ~half a budget: one more trade
        // fits, the next does not.
        System::set_block_number(start + BASKET_TRADE_REFILL_BLOCKS / 2);
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        let expected = budget - mid_1 - mid_2 + budget / 2;
        assert!(
            status.tao_available.to_u64().abs_diff(expected) <= budget / 1_000,
            "available {} vs expected {expected}",
            status.tao_available
        );
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTurnoverBudgetExceeded
        );

        // A full refill period after the last trade the bucket is full again — and no
        // fuller: the level clamps at one budget.
        System::set_block_number(
            start + BASKET_TRADE_REFILL_BLOCKS / 2 + BASKET_TRADE_REFILL_BLOCKS,
        );
        let budget_now = SubtensorModule::basket_trade_budget_tao(guarded_nav(&fund.hotkey));
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        assert_eq!(status.tao_available.to_u64(), budget_now);
        System::set_block_number(start + 10 * BASKET_TRADE_REFILL_BLOCKS);
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        assert_eq!(
            status.tao_available.to_u64(),
            budget_now,
            "clamped at one budget"
        );
    });
}

/// Root cash is TAO 1:1, so a root-origin trade charges exactly its amount.
#[test]
fn test_swap_basket_turnover_charges_root_origin_at_face() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        assert_ok!(swap(&fund, fund.netuid_a, NetUid::ROOT, 3 * TRADE));
        let start = System::block_number();
        refill_turnover_bucket(&fund.hotkey);
        let budget = SubtensorModule::basket_trade_budget_tao(guarded_nav(&fund.hotkey));

        assert_ok!(swap(&fund, NetUid::ROOT, fund.netuid_b, TRADE));
        assert_eq!(
            BasketTradeBucket::<Test>::get(fund.hotkey),
            Some((budget - TRADE, start))
        );
    });
}

// =============================================================================
// Guardrail: concentration cap
// =============================================================================

/// With enough destinations on chain (root + A + B = 3, cap 1/2) the destination holding
/// may not end above the cap share of NAV; smaller trades pass.
#[test]
fn test_swap_basket_refuses_destination_over_concentration_cap() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        assert_eq!(SubtensorModule::get_all_subnet_netuids().len(), 3);
        BasketConcentrationCap::<Test>::put(u16::MAX / 2);
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);

        // 60% of the fund into B: over the cap.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, held * 6 / 10),
            Error::<Test>::BasketConcentrationCapExceeded
        );
        // 40% is fine.
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, held * 4 / 10));
        // Topping B up past the cap is refused even though this trade alone is small.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, held * 2 / 10),
            Error::<Test>::BasketConcentrationCapExceeded
        );
        // The cash slot is a destination like any other.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, NetUid::ROOT, held * 6 / 10),
            Error::<Test>::BasketConcentrationCapExceeded
        );
    });
}

/// Selling out of a holding that is already over the cap is always allowed; only the
/// destination is checked.
#[test]
fn test_swap_basket_allows_selling_out_of_over_cap_position() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Build the over-cap position while the cap is not binding (default 1/16 needs 16
        // destinations), then make it binding.
        assert_ok!(swap(
            &fund,
            fund.netuid_a,
            fund.netuid_b,
            escrow_alpha(&fund.hotkey, fund.netuid_a)
        ));
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), 0);
        refill_turnover_bucket(&fund.hotkey);
        BasketConcentrationCap::<Test>::put(u16::MAX / 2);
        let held_b = escrow_alpha(&fund.hotkey, fund.netuid_b);

        // B holds 100% (> 50%): selling 30% of it back into A is allowed ...
        assert_ok!(swap(&fund, fund.netuid_b, fund.netuid_a, held_b * 3 / 10));
        // ... but moving 60% would put A over the cap.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_b, fund.netuid_a, held_b * 6 / 10),
            Error::<Test>::BasketConcentrationCapExceeded
        );
    });
}

/// Young-chain softening: with fewer destinations than the cap demands (3 < 16 at the
/// default 1/16), the concentration rule is skipped and a whole holding can move.
#[test]
fn test_swap_basket_concentration_cap_skipped_on_young_chain() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        assert!(
            SubtensorModule::binding_basket_concentration_cap(
                SubtensorModule::get_all_subnet_netuids().len() as u64
            )
            .is_none()
        );
        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, held));
        assert_eq!(escrow_alpha(&fund.hotkey, fund.netuid_a), 0);
    });
}

// =============================================================================
// Guardrails follow the fund on hotkey swap
// =============================================================================

#[test]
fn test_swap_basket_freeze_and_bucket_follow_hotkey_swap() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        let new_hotkey = U256::from(10030);
        // The swap target must be a hotkey the same coldkey owns (a subnet-scoped swap does
        // not create ownership).
        let _ = SubtensorModule::create_account_if_non_existent(&fund.coldkey, &new_hotkey);

        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, TRADE));
        let bucket = BasketTradeBucket::<Test>::get(fund.hotkey).expect("trade stores the bucket");
        BasketTradingFrozen::<Test>::insert(fund.hotkey, ());

        let mut weight = Weight::zero();
        assert_ok!(SubtensorModule::perform_hotkey_swap_on_one_subnet(
            &fund.hotkey,
            &new_hotkey,
            &mut weight,
            NetUid::ROOT,
            false,
        ));

        // The freeze is copied (the old key stays frozen too), the bucket moves.
        assert!(BasketTradingFrozen::<Test>::contains_key(new_hotkey));
        assert!(BasketTradingFrozen::<Test>::contains_key(fund.hotkey));
        assert_eq!(BasketTradeBucket::<Test>::get(new_hotkey), Some(bucket));
        assert_eq!(BasketTradeBucket::<Test>::get(fund.hotkey), None);

        // `register_on_root` only writes `Uids` (no `Keys` row), so the subnet-scoped swap
        // above cannot carry the root seat over; give the new hotkey its seat directly.
        register_on_root(&new_hotkey, 0);

        // The new hotkey is frozen: no trades until governance lifts it.
        let new_fund = Fund {
            hotkey: new_hotkey,
            ..fund
        };
        crate::assert_noop_ignore_postinfo!(
            swap(&new_fund, new_fund.netuid_b, new_fund.netuid_a, TRADE),
            Error::<Test>::BasketTradingFrozen
        );
        BasketTradingFrozen::<Test>::remove(new_hotkey);
        // And the moved bucket is what the next trade draws from: tightening the cap clamps
        // the carried level to the new (smaller) budget, then the trade takes its tao_mid.
        BasketDailyTurnoverCap::<Test>::put(DEFAULT_BASKET_DAILY_TURNOVER_CAP);
        let budget = SubtensorModule::basket_trade_budget_tao(guarded_nav(&new_hotkey));
        assert!(
            bucket.0 > budget,
            "carried level exceeds the tightened budget"
        );
        let held_b = escrow_alpha(&new_hotkey, new_fund.netuid_b);
        assert_ok!(swap(
            &new_fund,
            new_fund.netuid_b,
            new_fund.netuid_a,
            held_b
        ));
        let (_, mid, _) = last_swap_event();
        assert_eq!(
            BasketTradeBucket::<Test>::get(new_hotkey),
            Some((budget - mid, System::block_number()))
        );
    });
}

// =============================================================================
// Event index stability
// =============================================================================

/// `BasketSwapped` is appended after the 463 security-base events so live
/// testnet/devnet indices stay stable. `BasketAlphaWrittenOff` remains 148;
/// `SubnetLeaseDividendSkipped` and `SharePoolDenominatorReconciled` occupy
/// 149 and 150; `BasketSwapped` is 151.
#[test]
fn regression_basket_swapped_event_index_is_appended() {
    let prior_tail = Event::<Test>::BasketAlphaWrittenOff {
        hotkey: U256::from(1),
        netuid: NetUid::from(1),
        alpha: AlphaBalance::from(1),
    }
    .encode();
    let swapped = Event::<Test>::BasketSwapped {
        hotkey: U256::from(1),
        origin_netuid: NetUid::from(1),
        destination_netuid: NetUid::from(2),
        alpha_sold: AlphaBalance::from(1),
        tao_mid: TaoBalance::from(1),
        alpha_bought: AlphaBalance::from(1),
    }
    .encode();
    assert_eq!(prior_tail[0], 148);
    let lease_skipped = Event::<Test>::SubnetLeaseDividendSkipped {
        lease_id: 0,
        contributor: U256::from(1),
        alpha: AlphaBalance::from(1),
    }
    .encode();
    let reconciled = Event::<Test>::SharePoolDenominatorReconciled {
        hotkey: U256::from(1),
        netuid: NetUid::from(1),
    }
    .encode();
    assert_eq!(lease_skipped[0], 149);
    assert_eq!(reconciled[0], 150);
    assert_eq!(swapped[0], 151);

    // 463 error tail. A merge that reorders these is the 462-vs-463 collision.
    assert_eq!(Error::<Test>::RootWeightCapExceeded.encode()[0], 160);
    assert_eq!(Error::<Test>::BasketDepositPending.encode()[0], 161);
    assert_eq!(Error::<Test>::InvalidBatchLength.encode()[0], 162);
    assert_eq!(Error::<Test>::TooManyStakingHotkeys.encode()[0], 163);
    assert_eq!(Error::<Test>::ColdkeySwapTooHeavy.encode()[0], 164);
    assert_eq!(
        Error::<Test>::BasketConcentrationCapExceeded.encode()[0],
        165
    );
    assert_eq!(Error::<Test>::BasketMinOutNotMet.encode()[0], 171);
    assert_eq!(Error::<Test>::BasketSwapBatchEmpty.encode()[0], 172);

    let legs: BoundedVec<_, ConstU32<MAX_BASKET_SWAP_LEGS>> =
        vec![(NetUid::from(1), NetUid::from(2), AlphaBalance::from(1), 0)]
            .try_into()
            .expect("one leg is bounded");
    let call = crate::Call::<Test>::swap_basket_many {
        hotkey: U256::from(1),
        legs,
    }
    .encode();
    assert_eq!(call[0], 151);
}

// =============================================================================
// Documented weaknesses (calibration pass on PR #3150)
//
// These tests pin *current* behaviour so the weaknesses are visible in CI. Each is
// expected to PASS today; when a fix for the referenced finding lands, the assertion it
// names will flip and the test must be inverted or removed together with the fix.
// Finding numbers refer to `docs/pr-3150-swap-basket-exploit-calibration.md` (§2.x, §4).
// =============================================================================

/// Deep-cash fund plus one thin subnet C (1 000 τ / 100 000 α, price 0.01, EMA = spot),
/// with enough networks on chain for the 1/16 concentration cap to bind.
fn setup_cash_fund_with_thin_pool() -> (Fund, NetUid) {
    let coldkey = U256::from(1001);
    let hotkey = U256::from(1002);
    let staker = U256::from(1003);
    let owner_c = U256::from(3001);
    let hotkey_c = U256::from(3002);

    let netuid_a = add_dynamic_network(&hotkey, &coldkey);
    let netuid_c = add_dynamic_network(&hotkey_c, &owner_c);
    remove_owner_registration_stake(netuid_a);
    remove_owner_registration_stake(netuid_c);
    fund_pool(netuid_a);
    SubnetMovingPrice::<Test>::insert(netuid_a, I96F32::from_num(1));
    SubnetFastMovingPrice::<Test>::insert(netuid_a, U64F64::from_num(1));
    // Thin pool: 1 000 τ against 100 000 α.
    SubnetTAO::<Test>::insert(netuid_c, TaoBalance::from(THIN_POOL_TAO));
    SubnetAlphaIn::<Test>::insert(netuid_c, AlphaBalance::from(THIN_POOL_ALPHA));
    SubnetMovingPrice::<Test>::insert(netuid_c, I96F32::from_num(0.01));
    SubnetFastMovingPrice::<Test>::insert(netuid_c, U64F64::from_num(0.01));

    SubtensorModule::set_tao_weight(u64::MAX);
    zero_claim_threshold();
    register_on_root(&hotkey, 0);
    NetworksAdded::<Test>::insert(NetUid::ROOT, true);
    // 16 destinations on chain so `BasketConcentrationCap` (1/16) is enforced.
    for raw in 100u16..113 {
        NetworksAdded::<Test>::insert(NetUid::from(raw), true);
    }
    assert!(
        SubtensorModule::binding_basket_concentration_cap(
            SubtensorModule::get_all_subnet_netuids().len() as u64
        )
        .is_some()
    );

    // The fund holds 100 000 τ of cash in the root slot, backed by balance on the root pot
    // and counted in the root reserves; shares are outstanding so NAV/share is 1.
    let escrow = SubtensorModule::get_beta_escrow_account_id();
    let root_account = SubtensorModule::get_subnet_account_id(NetUid::ROOT).unwrap();
    add_balance_to_coldkey_account(&root_account, TaoBalance::from(CASH_NAV));
    SubtensorModule::increase_stake_for_hotkey_and_coldkey_on_subnet(
        &hotkey,
        &escrow,
        NetUid::ROOT,
        CASH_NAV.into(),
    );
    SubnetTAO::<Test>::mutate(NetUid::ROOT, |t| *t = t.saturating_add(CASH_NAV.into()));
    SubnetAlphaOut::<Test>::mutate(NetUid::ROOT, |t| *t = t.saturating_add(CASH_NAV.into()));
    TotalStake::<Test>::mutate(|t| *t = t.saturating_add(CASH_NAV.into()));
    BasketShares::<Test>::insert(hotkey, CASH_NAV);
    mock_increase_stake_for_hotkey_and_coldkey_on_subnet(
        &hotkey,
        &staker,
        NetUid::ROOT,
        2_000_000u64.into(),
    );

    BasketTradingEnabled::<Test>::put(true);
    (
        Fund {
            coldkey,
            hotkey,
            staker,
            netuid_a,
            netuid_b: netuid_c,
        },
        netuid_c,
    )
}

/// 100 000 τ of fund cash.
const CASH_NAV: u64 = 100_000_000_000_000;
/// Thin pool reserves: 1 000 τ and 100 000 α (price 0.01).
const THIN_POOL_TAO: u64 = 1_000_000_000_000;
const THIN_POOL_ALPHA: u64 = 100_000_000_000_000;
/// One buy slice of 9 τ: < 1% of the thin pool's TAO, so its own price impact is < 2%.
const SLICE: u64 = 9_000_000_000;

fn spot(netuid: NetUid) -> f64 {
    <Test as crate::Config>::SwapInterface::current_alpha_price(netuid.into()).to_num::<f64>()
}

/// A counterparty sells (fee-free) exactly enough alpha into `netuid` to bring spot back
/// down to `target_price`, pulling the fund's TAO out of the pool.
fn counterparty_sells_back_to(netuid: NetUid, target_price: f64) {
    let tao = SubnetTAO::<Test>::get(netuid).to_u64() as f64;
    let alpha_in = SubnetAlphaIn::<Test>::get(netuid).to_u64() as f64;
    // Constant product: k = tao * alpha; at the target price alpha' = sqrt(k / p).
    let target_alpha = (tao * alpha_in / target_price).sqrt();
    let sell = target_alpha - alpha_in;
    if sell < 1.0 {
        return;
    }
    let out = SubtensorModule::swap_alpha_for_tao(
        netuid,
        AlphaBalance::from(sell as u64),
        <Test as crate::Config>::SwapInterface::min_price::<TaoBalance>(),
        true,
    )
    .expect("counterparty sale fills");
    // The counterparty walks away with the TAO (leaves the pot).
    assert_ok!(SubtensorModule::transfer_tao_from_subnet(
        netuid,
        &U256::from(9_999),
        out.amount_paid_out.into(),
    ));
}

/// Finding §2.1 (High), fixed by the liquidity-relative destination cap (§5.1): sliced buys
/// into a thin pool, each answered by a counterparty sell-back to the EMA, used to pass
/// every guardrail and drain ~8% of NAV inside one turnover window, because the
/// concentration cap measures *realizable* value (bounded by the pool's TAO reserve). Now
/// the loop stops as soon as the fund holds `BasketLiquidityCap` of the pool's alpha
/// reserve, long before the turnover budget, and the loss is a sliver of the pool.
#[test]
fn finding_2_1_thin_pool_drain_is_stopped_by_liquidity_cap() {
    new_test_ext(1).execute_with(|| {
        let (fund, netuid_c) = setup_cash_fund_with_thin_pool();
        let nav_before = nav(&fund.hotkey);
        assert_eq!(nav_before, CASH_NAV);
        let budget = SubtensorModule::basket_trade_budget_tao(nav_before);

        let mut trades = 0u32;
        let mut spent = 0u64;
        let refused_with = loop {
            match swap(&fund, NetUid::ROOT, netuid_c, SLICE) {
                Ok(_) => {
                    trades += 1;
                    spent += SLICE;
                    counterparty_sells_back_to(netuid_c, 0.01);
                }
                Err(err) => break err.error,
            }
        };

        // The liquidity cap, not the turnover budget, stops the loop — early.
        assert_eq!(
            refused_with,
            Error::<Test>::BasketLiquidityCapExceeded.into()
        );
        assert!(trades < 50, "trades = {trades}");
        assert!(spent < budget / 5, "spent {spent} of budget {budget}");

        // The fund holds at most the cap's share of the pool's alpha reserve.
        let holding = escrow_alpha(&fund.hotkey, netuid_c);
        let reserve = SubnetAlphaIn::<Test>::get(netuid_c).to_u64();
        assert!(SubtensorModule::share_within_cap(
            holding,
            reserve,
            BasketLiquidityCap::<Test>::get() as u64
        ));

        // Loss is bounded by ~R × L² / (1 + L) of the pool's TAO reserve (≈ 1% at 10%),
        // plus fees — not by the turnover budget.
        let nav_after = nav(&fund.hotkey);
        let loss = nav_before - nav_after;
        assert!(
            loss < THIN_POOL_TAO * 3 / 100,
            "loss {loss} must be a sliver of the {THIN_POOL_TAO} pool"
        );
        assert!(loss < nav_before / 1_000, "loss {loss} vs NAV {nav_before}");
    });
}

/// Finding §2.2 (Medium), fixed by the token bucket (§5.2): a fixed window with a lazy
/// reset let a trader spend one full budget at block `start + 7199` and another at
/// `start + 7200`. With the bucket, spending the budget empties it, the very next block
/// refills only `budget / 7200`, and two adjacent blocks can never move more than one
/// budget (plus one block of refill).
#[test]
fn finding_2_2_bucket_denies_a_second_budget_in_the_adjacent_block() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        BasketDailyTurnoverCap::<Test>::put(u16::MAX / 2);
        let budget = SubtensorModule::basket_trade_budget_tao(guarded_nav(&fund.hotkey));
        let start = System::block_number();

        // Spend the whole bucket in this block (two slices; tao_mid trails alpha by the fee).
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, budget / 2));
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, budget / 2));
        let (level, block) = BasketTradeBucket::<Test>::get(fund.hotkey).expect("bucket stored");
        assert_eq!(block, start);
        assert!(
            level < budget / 100,
            "bucket nearly empty: {level} of {budget}"
        );
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTurnoverBudgetExceeded
        );
        let moved_first_block = budget - level;

        // Very next block: only one block's refill is available, far below a second budget.
        System::set_block_number(start + 1);
        let per_block = budget / BASKET_TRADE_REFILL_BLOCKS;
        let status = SubtensorModule::get_basket_trading_status(&fund.hotkey);
        assert!(status.tao_available.to_u64() <= level + per_block + 1);
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, budget / 2),
            Error::<Test>::BasketTurnoverBudgetExceeded
        );
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::BasketTurnoverBudgetExceeded
        );

        // Across the two adjacent blocks at most one budget (+ one refill step) moved.
        assert!(moved_first_block <= budget);
        assert!(
            status.tao_available.to_u64() + moved_first_block <= budget + per_block + 1,
            "two adjacent blocks must not exceed one budget"
        );

        // A full refill period later the bucket is whole again.
        System::set_block_number(start + BASKET_TRADE_REFILL_BLOCKS);
        let budget_now = SubtensorModule::basket_trade_budget_tao(guarded_nav(&fund.hotkey));
        assert_eq!(
            SubtensorModule::get_basket_trading_status(&fund.hotkey)
                .tao_available
                .to_u64(),
            budget_now
        );
        assert_ok!(swap(&fund, fund.netuid_a, fund.netuid_b, budget_now / 2));
    });
}

/// Finding §2.3, fixed: the 2% band is per leg, but every leg is bound to the fast
/// anchor as well as the slow EMA and spot. With spot 20% below a stale-high slow EMA,
/// chained buy legs in one block can no longer walk the price up toward the slow EMA
/// (`ceiling = 1.02 × min(slow, fast, spot)` with the fast anchor at the block's opening
/// price): the walk stops within 2% of where the pool opened.
#[test]
fn finding_2_3_chained_legs_in_one_block_stop_at_fast_anchor() {
    new_test_ext(1).execute_with(|| {
        let (fund, netuid_c) = setup_cash_fund_with_thin_pool();
        // Isolate the band: the walk would otherwise hit the liquidity cap first.
        BasketLiquidityCap::<Test>::put(u16::MAX);
        // Spot 0.01 sits 20% below a stale 0.0125 slow EMA; the fast anchor is the spot the
        // pool opened the block at.
        let ema = 0.0125f64;
        SubnetMovingPrice::<Test>::insert(netuid_c, I96F32::from_num(ema));
        let spot_before = spot(netuid_c);
        SubnetFastMovingPrice::<Test>::insert(netuid_c, U64F64::from_num(spot_before));
        let block = System::block_number();

        let mut legs = 0u32;
        let refused_with = loop {
            match swap(&fund, NetUid::ROOT, netuid_c, SLICE) {
                Ok(_) => legs += 1,
                Err(err) => break err.error,
            }
        };
        assert_eq!(System::block_number(), block, "all legs ran in one block");
        assert_eq!(refused_with, Error::<Test>::SlippageTooHigh.into());

        let spot_after = spot(netuid_c);
        assert!(legs >= 1, "legs = {legs}");
        // Stopped by the fast anchor: within 2% of the opening price, far below the stale
        // slow EMA that used to be the binding ceiling.
        assert!(
            spot_after <= spot_before * 1.02 * 1.001,
            "price moved {spot_before} -> {spot_after} in one block"
        );
        assert!(spot_after < ema);
    });
}

/// Finding §4 "crash lock": once spot sits 5% below the EMA a fund cannot sell even one
/// unit of the holding (no stop-loss), and 5% above it cannot buy. Documents current
/// behaviour; flip when a wider sell-side tolerance (§5.3) lands.
#[test]
fn finding_crash_lock_blocks_selling_a_falling_holding() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Spot is 1.0 on both pools. A's EMA is 5% above spot: the fund holds A and cannot
        // sell any of it — into another subnet or into cash.
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(1.0 / 0.95));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, NetUid::ROOT, TRADE),
            Error::<Test>::SlippageTooHigh
        );
        SubnetMovingPrice::<Test>::insert(fund.netuid_a, I96F32::from_num(1));

        // B's EMA is 5% below spot: the fund cannot buy B.
        SubnetMovingPrice::<Test>::insert(fund.netuid_b, I96F32::from_num(0.95));
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, fund.netuid_b, TRADE),
            Error::<Test>::SlippageTooHigh
        );
    });
}

/// Finding §4 "cash slot": root is a capped destination like any subnet, so with the cap
/// binding a fund cannot hold more than `BasketConcentrationCap` (1/16) of NAV as TAO — it cannot
/// de-risk into cash. Documents current behaviour; flip when a separate cash cap (§5.4)
/// lands.
#[test]
fn finding_cash_slot_is_capped_at_concentration_cap() {
    new_test_ext(1).execute_with(|| {
        let fund = setup_fund();
        // Root + A + B + 13 placeholders = 16 destinations: the default 1/16 cap binds.
        for raw in 100u16..113 {
            NetworksAdded::<Test>::insert(NetUid::from(raw), true);
        }
        let available = SubtensorModule::get_all_subnet_netuids().len() as u64;
        assert_eq!(available, 16);
        assert_eq!(
            SubtensorModule::binding_basket_concentration_cap(available),
            Some(u64::from(BasketConcentrationCap::<Test>::get()))
        );

        let held = escrow_alpha(&fund.hotkey, fund.netuid_a);
        // 10% of the fund into cash: refused.
        crate::assert_noop_ignore_postinfo!(
            swap(&fund, fund.netuid_a, NetUid::ROOT, held / 10),
            Error::<Test>::BasketConcentrationCapExceeded
        );
        // 6% (just under 1/16): allowed.
        assert_ok!(swap(&fund, fund.netuid_a, NetUid::ROOT, held * 6 / 100));
        assert!(escrow_alpha(&fund.hotkey, NetUid::ROOT) > 0);
    });
}
