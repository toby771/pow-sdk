#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
JS_TESTS="$REPO_ROOT/clones/js-tests"

usage() {
  echo "usage: run-clone-regression-phase.sh pristine|remaining|combined" >&2
  exit 2
}

[[ $# -eq 1 ]] || usage
phase=$1
[[ "$phase" == pristine || "$phase" == remaining || "$phase" == combined ]] || usage

run_sdk_drift=${RUN_SDK_DRIFT:-false}
[[ "$run_sdk_drift" == true || "$run_sdk_drift" == false ]] || {
  echo "RUN_SDK_DRIFT must be true or false" >&2
  exit 2
}

sdk_sync_pid=""
sdk_sync_log=""

cleanup() {
  local status=$?
  [[ -z "$sdk_sync_pid" ]] || kill "$sdk_sync_pid" 2>/dev/null || true
  "$SCRIPT_DIR/stop-local-clone.sh" || true
  exit "$status"
}
trap cleanup EXIT

start_clone() {
  "$SCRIPT_DIR/start-local-clone-and-wait.sh" accelerated
}

upgrade_runtime() {
  (
    cd "$JS_TESTS"
    npm run runtime:update:alice || { sleep 15; npm run runtime:update:alice; }
  )
}

run_regressions() {
  local selected_phase=$1
  (
    cd "$JS_TESTS"
    CLONE_REGRESSION_PHASE="$selected_phase" \
      CLONE_REGRESSION_TIMEOUT_MS=1800000 \
      npm run test:clone-regressions
  )
}

run_pristine() {
  start_clone
  upgrade_runtime
  run_regressions pristine
}

# `uv sync` builds the SDK's Rust extension (~1.5 min). Start it before the
# clone boots so it overlaps the upgrade and regression tests instead of
# extending this required gate; the drift check itself still runs afterwards
# against the upgraded chain.
start_sdk_sync() {
  [[ "$run_sdk_drift" == true ]] || return 0
  if ! command -v uv >/dev/null 2>&1; then
    curl -LsSf https://astral.sh/uv/0.11.28/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
  fi
  sdk_sync_log=$(mktemp)
  (
    cd "$REPO_ROOT/sdk/python"
    uv sync --locked --all-extras --dev
  ) >"$sdk_sync_log" 2>&1 &
  sdk_sync_pid=$!
}

run_sdk_metadata_drift() {
  [[ "$run_sdk_drift" == true ]] || return 0
  local sync_status=0
  wait "$sdk_sync_pid" || sync_status=$?
  sdk_sync_pid=""
  cat "$sdk_sync_log"
  rm -f "$sdk_sync_log"
  if [[ "$sync_status" -ne 0 ]]; then
    echo "SDK environment sync failed (exit $sync_status)" >&2
    return "$sync_status"
  fi
  (
    cd "$REPO_ROOT/sdk/python"
    uv run python -m codegen.check --drift "${WS_ENDPOINT:-ws://127.0.0.1:9944}"
  )
}

run_remaining() {
  start_sdk_sync
  start_clone
  upgrade_runtime
  (
    cd "$JS_TESTS"
    npm test
  )
  run_regressions remaining
  run_sdk_metadata_drift
}

case "$phase" in
  pristine)
    run_pristine
    ;;
  remaining)
    run_remaining
    ;;
  combined)
    : "${CLONE_CHECKPOINT:?CLONE_CHECKPOINT is required for combined execution}"
    run_pristine
    "$SCRIPT_DIR/stop-local-clone.sh"
    "$SCRIPT_DIR/local-clone-checkpoint.sh" restore "$CLONE_CHECKPOINT"
    run_remaining
    ;;
esac
